/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Telas;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author aluno
 */
public class TelaAdicionarItem extends javax.swing.JFrame {

    /**
     * Creates new form Tela_detalhes_pedido
     */
    public TelaAdicionarItem() {
        initComponents();
        setExtendedState(TelaAdicionarItem.MAXIMIZED_BOTH);
    }
    
    private void SelectItem(String sql) {
    
        try {
            Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3309/db_grandprix_dds", "root", "usbw");
            PreparedStatement banco = (PreparedStatement)con.prepareStatement(sql);
            banco.execute(); 
            
            ResultSet resultado = banco.executeQuery(sql);
 
            while(resultado.next())
            {
                combo_item.addItem(resultado.getString("nome_item"));               
            }
            
            banco.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println("o erro foi " +ex);
        }
    }
    
private void MetodoTable2(String sql) {
        try {
            Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3309/db_grandprix_dds", "root", "usbw");
            PreparedStatement banco = (PreparedStatement)con.prepareStatement(sql);
            banco.execute(); 
            
            ResultSet resultado = banco.executeQuery(sql);
            
            DefaultTableModel model =(DefaultTableModel) table_itens.getModel();
            model.setNumRows(0);
            
            while(resultado.next())
            {
                model.addRow(new Object[]
                {
                    resultado.getString("nome_item"),                   
                    resultado.getString("quantidade"),
                    resultado.getString("tamanho"),
                    resultado.getString("cor"),
                    resultado.getString("tipo")
    
                });
            }
            banco.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println("o erro foi " +ex);
        }
    }
    public void MetodoAttPedido(String sql) {
        
        try {
                        
            Connection con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost:3309/db_grandprix_dds", "root", "usbw");
            PreparedStatement banco = (PreparedStatement)con.prepareStatement(sql);
            
            banco.execute(); 
            
            ResultSet resultado = banco.executeQuery(sql);
            
            
            
            while(resultado.next())
            {                    
                    Numeropedido.setText(resultado.getString("numero_pedido"));
  
            }
            
            if (resultado.isAfterLast() == true){
                
            
            
            } else if (resultado.isBeforeFirst() == false){


            }
            
            banco.close();
            con.close();
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(rootPane," Falha ao exportar Pedido " + ex);
               
                dispose();
            
        }
     }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        combo_item = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        quantidade = new javax.swing.JTextField();
        cortxt = new javax.swing.JTextField();
        tamanho = new javax.swing.JTextField();
        tipotxt = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        Numeropedido = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        table_itens = new javax.swing.JTable();
        jSeparator1 = new javax.swing.JSeparator();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        botao_cadastrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(0, 204, 102));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 0)));
        jPanel2.setPreferredSize(new java.awt.Dimension(190, 88));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Dialog", 1, 55)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Pedidos");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(10, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 70)); // NOI18N
        jLabel2.setText("Detalhes do Pedido");

        jLabel3.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        jLabel3.setText("Item:");

        combo_item.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        combo_item.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione..." }));
        combo_item.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                combo_itemAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });

        jLabel4.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        jLabel4.setText("Quantidade:");

        jLabel5.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        jLabel5.setText("Tamanho:");

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        jLabel6.setText("Cor:");

        jLabel7.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        jLabel7.setText("Tipo:");

        quantidade.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

        cortxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

        tamanho.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

        tipotxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

        jLabel8.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        jLabel8.setText("Número do Pedido:");

        Numeropedido.setBackground(new java.awt.Color(204, 204, 204));
        Numeropedido.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        Numeropedido.setEnabled(false);

        table_itens.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item", "Quantidade", "Tamanho", "Cor", "Tipo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(table_itens);

        jSeparator1.setBackground(new java.awt.Color(0, 0, 0));

        jButton1.setBackground(new java.awt.Color(51, 204, 0));
        jButton1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jButton1.setText("Excluir");

        jButton2.setBackground(new java.awt.Color(51, 204, 0));
        jButton2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jButton2.setText("+");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        botao_cadastrar.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        botao_cadastrar.setText("Finalizar Pedido");
        botao_cadastrar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        botao_cadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botao_cadastrarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botao_cadastrarMouseExited(evt);
            }
        });
        botao_cadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botao_cadastrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 1550, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addGap(18, 18, 18)
                                        .addComponent(quantidade, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(combo_item, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(23, 23, 23)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(18, 18, 18)
                                        .addComponent(tamanho, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(18, 18, 18)
                                        .addComponent(cortxt)))
                                .addGap(37, 37, 37)
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tipotxt, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(297, 297, 297)
                                .addComponent(jLabel8)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Numeropedido, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton2)
                                .addGap(18, 18, 18)
                                .addComponent(jButton1)))
                        .addGap(0, 10, Short.MAX_VALUE))
                    .addComponent(jScrollPane1))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botao_cadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(99, 99, 99))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel8)
                        .addComponent(Numeropedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(51, 51, 51)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5)
                    .addComponent(tamanho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(tipotxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(combo_item, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(quantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(cortxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 296, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(botao_cadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botao_cadastrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botao_cadastrarMouseEntered

        Color fundo = new Color(0,204,102);
        Color fonte = new Color(255,255,255);
        botao_cadastrar.setBackground(fundo);
        botao_cadastrar.setForeground(fonte);
    }//GEN-LAST:event_botao_cadastrarMouseEntered

    private void botao_cadastrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botao_cadastrarMouseExited
        Color fonte = new Color(0,0,0);
        Color fundo = new Color(255,255,255);

        botao_cadastrar.setBackground(fundo);
        botao_cadastrar.setForeground(fonte);
    }//GEN-LAST:event_botao_cadastrarMouseExited

    private void botao_cadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botao_cadastrarActionPerformed
        

        try {

            Connection conexao = null;
            PreparedStatement statement = null;

            String url = "jdbc:mysql://localhost:3309/db_grandprix_dds";
            String usuario = "root";
            String senha = "usbw";

            conexao = DriverManager.getConnection(url, usuario, senha);

            String sql = "INSERT INTO itens_pedido_saida (numero_pedido,nome_item,quantidade,tamanho,cor," +
            "tipo) VALUES (?,?,?,?,?,?)";

            statement = conexao.prepareStatement(sql);

            statement.setString(1, this.Numeropedido.getText());
            statement.setString(2, combo_item.getSelectedItem().toString());
            statement.setString(3,quantidade.getText());
            statement.setString(4,tamanho.getText());
            statement.setString(5,cortxt.getText());
            statement.setString(6,tipotxt.getText());

            int linhasAfetadas = statement.executeUpdate();

            if(linhasAfetadas > 0 ){

             MetodoTable2("select * from itens_pedido_saida where numero_pedido = " + this.Numeropedido.getText());

            }else {

                JOptionPane.showMessageDialog(rootPane, "Erro ao inserir");

            }

            statement.close();
            conexao.close();

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(rootPane, "Erro ao inserir: " + ex);

        }
    }//GEN-LAST:event_botao_cadastrarActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
        try {

            Connection conexao = null;
            PreparedStatement statement = null;

            String url = "jdbc:mysql://localhost:3309/db_grandprix_dds";
            String usuario = "root";
            String senha = "usbw";

            conexao = DriverManager.getConnection(url, usuario, senha);

            String sql = "INSERT INTO itens_pedido_saida (numero_pedido,nome_item,quantidade,tamanho,cor," +
            "tipo) VALUES (?,?,?,?,?,?)";

            statement = conexao.prepareStatement(sql);

            statement.setString(1, this.Numeropedido.getText());
            statement.setString(2, combo_item.getSelectedItem().toString());
            statement.setString(3,quantidade.getText());
            statement.setString(4,tamanho.getText());
            statement.setString(5,cortxt.getText());
            statement.setString(6,tipotxt.getText());

            int linhasAfetadas = statement.executeUpdate();

            if(linhasAfetadas > 0 ){


            }else {

                JOptionPane.showMessageDialog(rootPane, "Erro ao inserir");

            }

            statement.close();
            conexao.close();

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(rootPane, "Erro ao inserir: " + ex);

        }
      
    }//GEN-LAST:event_jButton2ActionPerformed

    private void combo_itemAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_combo_itemAncestorAdded
        
        combo_item.removeAll();
        SelectItem("select * from Cadastro_itens;");
        
        
    }//GEN-LAST:event_combo_itemAncestorAdded

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaAdicionarItem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaAdicionarItem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaAdicionarItem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaAdicionarItem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaAdicionarItem().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Numeropedido;
    private javax.swing.JButton botao_cadastrar;
    private javax.swing.JComboBox<String> combo_item;
    private javax.swing.JTextField cortxt;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField quantidade;
    private javax.swing.JTable table_itens;
    private javax.swing.JTextField tamanho;
    private javax.swing.JTextField tipotxt;
    // End of variables declaration//GEN-END:variables
}
